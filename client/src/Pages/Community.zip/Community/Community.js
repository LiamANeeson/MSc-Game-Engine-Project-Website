import React from 'react'
import './Community.css'

function Community() {
  return (
    <div className='community-container'>
      <div className='community-headline'>
        <h2 className='community-headline-text'>Featured Posts
          <button className='ask-q-btn'>Ask A Question</button>
        </h2>
        <div>
          <button className='allFilter-btn'>All</button>
          <button className='unansweredFilter-btn'>Unanswered</button>
          <label htmlFor="header-search">
          </label>
          <input
            type="text"
            id="header-search"
            placeholder="Search question"
            name="s"
          />
          <button type="submit">Search</button>

          <label htmlFor="header-sort">
          </label>
          <select name="cars" id="header-sort">
            <option value="asc">Sort by name(A-Z)</option>
            <option value="desc">Sort by name(Z-A)</option>
            <option value="opel">Sort by most votes</option>
            <option value="opel">Sort by most views</option>
            <option value="audi">Audi</option>
          </select>
          <button type="submit">Sort</button>
          <div class="pagination">
          <a href="#">&laquo;</a>
          <a href="#">1</a>
          <a href="#">2</a>
          <a href="#">3</a>
          <a href="#">4</a>
          <a href="#">&raquo;</a>
        </div>
        </div>
       
      </div>





      <div className='post-box-1 post-box'>
        <h2 className='question-title'>Question 1</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin efficitur sapien vitae nulla ornare, ut pharetra metus semper.
          Aenean nisl tortor, mollis nec mauris sed, hendrerit semper sem. Vivamus mattis id elit at ultrices. Quisque condimentum efficitur turpis ut luctus.
          Aliquam accumsan, quam nec imperdiet condimentum, libero elit imperdiet diam, sed suscipit arcu ex id lacus. Nulla egestas tempus mauris a tincidunt.
          In dignissim ultricies risus, nec viverra quam condimentum a. Nulla magna tellus, commodo quis tortor sed, condimentum maximus enim.
          Cras commodo velit quis nibh auctor maximus. Nunc urna magna, luctus sit amet pretium tristique, volutpat nec augue.
        </p>
      </div>
      <div className='post-box-2 .post-box'>
        <h2 className='question-title'>Question 2</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin efficitur sapien vitae nulla ornare, ut pharetra metus semper.
          Aenean nisl tortor, mollis nec mauris sed, hendrerit semper sem. Vivamus mattis id elit at ultrices. Quisque condimentum efficitur turpis ut luctus.
          Aliquam accumsan, quam nec imperdiet condimentum, libero elit imperdiet diam, sed suscipit arcu ex id lacus. Nulla egestas tempus mauris a tincidunt.
          In dignissim ultricies risus, nec viverra quam condimentum a. Nulla magna tellus, commodo quis tortor sed, condimentum maximus enim.
          Cras commodo velit quis nibh auctor maximus. Nunc urna magna, luctus sit amet pretium tristique, volutpat nec augue.
        </p>
      </div>
      <div className='post-box-3 .post-box'>
        <h2 className='question-title'>Question 3</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin efficitur sapien vitae nulla ornare, ut pharetra metus semper.
          Aenean nisl tortor, mollis nec mauris sed, hendrerit semper sem. Vivamus mattis id elit at ultrices. Quisque condimentum efficitur turpis ut luctus.
          Aliquam accumsan, quam nec imperdiet condimentum, libero elit imperdiet diam, sed suscipit arcu ex id lacus. Nulla egestas tempus mauris a tincidunt.
          In dignissim ultricies risus, nec viverra quam condimentum a. Nulla magna tellus, commodo quis tortor sed, condimentum maximus enim.
          Cras commodo velit quis nibh auctor maximus. Nunc urna magna, luctus sit amet pretium tristique, volutpat nec augue.
        </p>
      </div>
      <div className='post-box-4 .post-box'>
        <h2 className='question-title'>Question 4</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin efficitur sapien vitae nulla ornare, ut pharetra metus semper.
          Aenean nisl tortor, mollis nec mauris sed, hendrerit semper sem. Vivamus mattis id elit at ultrices. Quisque condimentum efficitur turpis ut luctus.
          Aliquam accumsan, quam nec imperdiet condimentum, libero elit imperdiet diam, sed suscipit arcu ex id lacus. Nulla egestas tempus mauris a tincidunt.
          In dignissim ultricies risus, nec viverra quam condimentum a. Nulla magna tellus, commodo quis tortor sed, condimentum maximus enim.
          Cras commodo velit quis nibh auctor maximus. Nunc urna magna, luctus sit amet pretium tristique, volutpat nec augue.
        </p>
      </div>
      <div className='post-box-5 .post-box'>
        <h2 className='question-title'>Question 5</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin efficitur sapien vitae nulla ornare, ut pharetra metus semper.
          Aenean nisl tortor, mollis nec mauris sed, hendrerit semper sem. Vivamus mattis id elit at ultrices. Quisque condimentum efficitur turpis ut luctus.
          Aliquam accumsan, quam nec imperdiet condimentum, libero elit imperdiet diam, sed suscipit arcu ex id lacus. Nulla egestas tempus mauris a tincidunt.
          In dignissim ultricies risus, nec viverra quam condimentum a. Nulla magna tellus, commodo quis tortor sed, condimentum maximus enim.
          Cras commodo velit quis nibh auctor maximus. Nunc urna magna, luctus sit amet pretium tristique, volutpat nec augue.
        </p>
      </div>
      <div className='post-box-6 .post-box'>
        <h2 className='question-title'>Question 6</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin efficitur sapien vitae nulla ornare, ut pharetra metus semper.
          Aenean nisl tortor, mollis nec mauris sed, hendrerit semper sem. Vivamus mattis id elit at ultrices. Quisque condimentum efficitur turpis ut luctus.
          Aliquam accumsan, quam nec imperdiet condimentum, libero elit imperdiet diam, sed suscipit arcu ex id lacus. Nulla egestas tempus mauris a tincidunt.
          In dignissim ultricies risus, nec viverra quam condimentum a. Nulla magna tellus, commodo quis tortor sed, condimentum maximus enim.
          Cras commodo velit quis nibh auctor maximus. Nunc urna magna, luctus sit amet pretium tristique, volutpat nec augue.
        </p>
      </div>
      <div className='post-box-7 .post-box'>
        <h2 className='question-title'>Question 7</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin efficitur sapien vitae nulla ornare, ut pharetra metus semper.
          Aenean nisl tortor, mollis nec mauris sed, hendrerit semper sem. Vivamus mattis id elit at ultrices. Quisque condimentum efficitur turpis ut luctus.
          Aliquam accumsan, quam nec imperdiet condimentum, libero elit imperdiet diam, sed suscipit arcu ex id lacus. Nulla egestas tempus mauris a tincidunt.
          In dignissim ultricies risus, nec viverra quam condimentum a. Nulla magna tellus, commodo quis tortor sed, condimentum maximus enim.
          Cras commodo velit quis nibh auctor maximus. Nunc urna magna, luctus sit amet pretium tristique, volutpat nec augue.
        </p>
      </div>
      <div className='post-box-8 .post-box'>
        <h2 className='question-title'>Question 8</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin efficitur sapien vitae nulla ornare, ut pharetra metus semper.
          Aenean nisl tortor, mollis nec mauris sed, hendrerit semper sem. Vivamus mattis id elit at ultrices. Quisque condimentum efficitur turpis ut luctus.
          Aliquam accumsan, quam nec imperdiet condimentum, libero elit imperdiet diam, sed suscipit arcu ex id lacus. Nulla egestas tempus mauris a tincidunt.
          In dignissim ultricies risus, nec viverra quam condimentum a. Nulla magna tellus, commodo quis tortor sed, condimentum maximus enim.
          Cras commodo velit quis nibh auctor maximus. Nunc urna magna, luctus sit amet pretium tristique, volutpat nec augue.
        </p>
      </div>
      <div className='post-box-9 .post-box'>
        <h2 className='question-title'>Question 9</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin efficitur sapien vitae nulla ornare, ut pharetra metus semper.
          Aenean nisl tortor, mollis nec mauris sed, hendrerit semper sem. Vivamus mattis id elit at ultrices. Quisque condimentum efficitur turpis ut luctus.
          Aliquam accumsan, quam nec imperdiet condimentum, libero elit imperdiet diam, sed suscipit arcu ex id lacus. Nulla egestas tempus mauris a tincidunt.
          In dignissim ultricies risus, nec viverra quam condimentum a. Nulla magna tellus, commodo quis tortor sed, condimentum maximus enim.
          Cras commodo velit quis nibh auctor maximus. Nunc urna magna, luctus sit amet pretium tristique, volutpat nec augue.
        </p>
      </div>
      <div>
        <div class="pagination">
          <a href="#">&laquo;</a>
          <a href="#">1</a>
          <a href="#">2</a>
          <a href="#">3</a>
          <a href="#">4</a>
          <a href="#">&raquo;</a>
        </div>
      </div>
    </div>


  )
}

export default Community